from django.urls import path
import blog.views as bv

urlpatterns = [
    path('', bv.allBlogs, name='allblogs'),
    path('<int:blog_id>/', bv.blogDetail, name='detail')
]
