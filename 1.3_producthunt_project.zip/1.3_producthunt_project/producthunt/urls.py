from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
import products.views as pv
import accounts.urls as au
import products.urls as pu

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', pv.home, name = 'home'),
    path('accounts/', include(au)),
    path('products/', include(pu)),
    ] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
