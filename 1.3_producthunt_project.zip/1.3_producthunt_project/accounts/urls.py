from django.contrib import admin
from django.urls import path
import accounts.views as av

urlpatterns = [
    path('signup/', av.signup, name='signup'),
    path('login/', av.login, name='login'),
    path('logout/', av.logout, name='logout'),
]
