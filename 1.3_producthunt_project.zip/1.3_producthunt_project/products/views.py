from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Product
from django.utils import timezone


def home(request):
    allProduct = Product.objects
    return render(request, 'home.html', {'allProduct': allProduct})


# if anyone is not logged in he/she will be redirected to login page
# ------------------------------------------------------------------
@login_required
def create(request):
    if request.method == 'POST':
        if request.POST['productTitle'] and request.POST['productUrl'] and request.POST['productdes'] and request.FILES[
            'productimage'] and request.FILES['producticon']:
            product = Product()
            product.title = request.POST['productTitle']
            product.description = request.POST['productdes']
            url = request.POST['productUrl']
            if url.startswith('http://') or url.startswith('https://'):
                product.url = url
            else:
                product.url = 'http://' + url
            product.product_image = request.FILES['productimage']
            product.product_icon = request.FILES['producticon']
            product.pub_date = timezone.datetime.now()
            product.hunter = request.user
            product.save()
            return redirect('home')
        else:
            return render(request, 'create.html', {'error': 'all fields are required'})

    else:
        return render(request, 'create.html')


def detail(request, productId):
    product_detail = get_object_or_404(Product, pk = productId)
    return render(request, 'productDetail.html', {'product_detail': product_detail})


@login_required(login_url = '/accounts/signup')
def vote(request, productId):
    voteTheProduct = get_object_or_404(Product, pk = productId)
    voteTheProduct.votes += 1
    voteTheProduct.save()
    return redirect('/products/' + str(productId))
