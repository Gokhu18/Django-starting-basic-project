from django.urls import path
import products.views as pv

urlpatterns = [
    path('create/', pv.create, name='create'),
    path('<int:productId>/', pv.detail, name='detail'),
    path('<int:productId>/vote', pv.vote, name='vote'),
    ]
